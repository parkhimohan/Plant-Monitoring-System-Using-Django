from __future__ import unicode_literals
from django.contrib import admin
from .models import *

admin.site.register(plant)
admin.site.register(plantID)
admin.site.register(weatherStation)
